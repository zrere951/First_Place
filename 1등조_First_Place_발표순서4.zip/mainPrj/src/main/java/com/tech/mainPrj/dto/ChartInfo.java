package com.tech.mainPrj.dto;

public class ChartInfo {
	private String cdate;
	private String cnt0;
	private String cnt1;
	private String cnt2;
	private String cnt3;
	private String cnt4;
	private String cnt5;
	private String cnt6;
	private String cnt7;
	private String cnt8;
	private String cnt9;
	private String cnt10;
	private String cnt11;
	
	
	public String getCdate() {
		return cdate;
	}
	public void setCdate(String cdate) {
		this.cdate = cdate;
	}
	public String getCnt0() {
		return cnt0;
	}
	public void setCnt0(String cnt0) {
		this.cnt0 = cnt0;
	}
	public String getCnt1() {
		return cnt1;
	}
	public void setCnt1(String cnt1) {
		this.cnt1 = cnt1;
	}
	public String getCnt2() {
		return cnt2;
	}
	public void setCnt2(String cnt2) {
		this.cnt2 = cnt2;
	}
	public String getCnt3() {
		return cnt3;
	}
	public void setCnt3(String cnt3) {
		this.cnt3 = cnt3;
	}
	public String getCnt4() {
		return cnt4;
	}
	public void setCnt4(String cnt4) {
		this.cnt4 = cnt4;
	}
	public String getCnt5() {
		return cnt5;
	}
	public void setCnt5(String cnt5) {
		this.cnt5 = cnt5;
	}
	public String getCnt6() {
		return cnt6;
	}
	public void setCnt6(String cnt6) {
		this.cnt6 = cnt6;
	}
	public String getCnt7() {
		return cnt7;
	}
	public void setCnt7(String cnt7) {
		this.cnt7 = cnt7;
	}
	public String getCnt8() {
		return cnt8;
	}
	public void setCnt8(String cnt8) {
		this.cnt8 = cnt8;
	}
	public String getCnt9() {
		return cnt9;
	}
	public void setCnt9(String cnt9) {
		this.cnt9 = cnt9;
	}
	public String getCnt10() {
		return cnt10;
	}
	public void setCnt10(String cnt10) {
		this.cnt10 = cnt10;
	}
	public String getCnt11() {
		return cnt11;
	}
	public void setCnt11(String cnt11) {
		this.cnt11 = cnt11;
	}

}
